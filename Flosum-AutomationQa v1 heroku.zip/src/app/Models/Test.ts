export class Test {
    Name: string;
    flosum_qa__selenium_webdriver_JS__c: string;
    flosum_qa__File_Name__c : string;
    constructor(){
      this.Name = '';
      this.flosum_qa__File_Name__c = '';
      this.flosum_qa__selenium_webdriver_JS__c = '';
    }
  }